package wlgmod::pdf;

# You need 'xpdf' to be able to use this plugin
#
# Get it at: http://www.foolabs.com/xpdf/

# PDF word extract plugin

my $pdftotext = "";
my $tmpfile   = "/tmp/wlg_tmp.1";

sub init {
    open(FILE, "which pdftotext|");
    chomp($pdftotext = <FILE>);
    close(FILE);
    if ($?) {
        return "Cannot find 'pdftotext' (http://www.foolabs.com/xpdf/)";
    }
    return "";
}

sub get_words {
	my $this = shift;
	my $filename = shift;
	my @words;

	system("$pdftotext -nopgbrk \"$filename\" $tmpfile");
	open(FILE, "<$tmpfile" ) || die "Cannot open $tmpfile: $!";
	undef $/; # switch into 'slurp' mode

	my $content = <FILE>;
	my @list = split (/\s/,$content);
	foreach my $word (@list)
	{
	    chomp $word;
	    $word =~ s/\s+//mg;
	    $word =~ s/[,.;:?]+//mg;
	    
	    if($word ne "") {
		push @words, $word;
	    }
	}
	close(FILE);
	
	system("rm $tmpfile");

	return (@words);
}

1;
