package wlgmod::strings;

# 'strings' word extract plugin

my $strings   = "";

sub init {
    open(FILE, "which strings|");
    chomp($strings = <FILE>);
    close(FILE);
    if ($?) {
        return "Cannot find 'strings'";
    }
    return "";
}

sub get_words {
	my $this = shift;
	my $filename = shift;
	my $num = shift;
	my @words;

        open(FILE, "$strings -n $num \"$filename\"|" ) || die "Cannot open $filename: $!";
        undef $/; # switch into 'slurp' mode

	my $content = <FILE>;
	my @list = split (/\s/,$content);
	foreach my $word (@list)
	{
	    chomp $word;
	    $word =~ s/\s+//mg;
	    $word =~ s/[,.;:?]+//mg;

	    if($word ne "") {
		push @words, $word;
	    }
	}
	close(FILE);

	return (@words);
}

1;
