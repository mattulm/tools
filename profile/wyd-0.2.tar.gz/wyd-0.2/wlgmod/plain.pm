package wlgmod::plain;

# PLAIN-Text word extract plugin

sub init {
    return "";
}

sub get_words {
	my $this = shift;
	my $filename = shift;
	my @words;

	open(FILE, "<$filename" ) || die "Cannot open $filename: $!";

	while (<FILE>)
	{
	   my @list = split (/\s/,$_);
	   foreach my $word (@list)
	   {
	       chomp $word;
	       $word =~ s/\s+//mg;
	       $word =~ s/[,.;:?]+//mg;
	       
	       if($word ne "") {
		   push @words, $word;
	       }
	   }
        }
	close(FILE);
	
	return (@words);
}

1;
