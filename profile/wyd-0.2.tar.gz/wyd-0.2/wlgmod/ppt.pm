package wlgmod::ppt;

# You need 'catppt' to be able to use this plugin
#
# Get it at: http://www.45.free.net/~vitus/software/catdoc/

# PPT word extract plugin

my $catppt="";

sub init {
    open(FILE, "which catppt|");
    chomp($catppt = <FILE>);
    close(FILE);	  
    if ($?) {
	return "Cannot find 'catppt' (http://www.45.free.net/~vitus/software/catdoc/)";
    }
    return "";
}

sub get_words {
	my $this = shift;
	my $filename = shift;
	my @words;

	open(FILE, "$catppt \"$filename\"|" ) || die "Cannot open $filename: $!";
	undef $/; # switch into 'slurp' mode

	my $content = <FILE>;
	my @list = split (/\s/,$content);
	foreach my $word (@list)
	{
	    chomp $word;
	    $word =~ s/\s+//mg;
	    $word =~ s/[,.;:?]+//mg;
	    
	    if($word ne "") {
		push @words, $word;
	    }
	}
	close(FILE);

	return (@words);
}

1;
