package wlgmod::jpeg;

# You need 'jhead' to be able to use this plugin
#
# Get it at: http://www.sentex.net/~mwandel/jhead/

# Exif jpeg file extraction plugin

my $jhead="";
my $tmpfile   = "/tmp/wlg_tmp.1";

sub init {
    open(FILE, "which jhead|");
    chomp($jhead = <FILE>);
    close(FILE);	  
    if ($?) {
	return "Cannot find 'jhead' (http://www.sentex.net/~mwandel/jhead/)";
    }
    return "";
}

sub get_words {
	my $this = shift;
	my $filename = shift;
	my @words;

	system("touch \"$tmpfile\""); # if no comment, no outfile
	system("$jhead -cs \"$tmpfile\" \"$filename\" >/dev/null 2>&1");
	open(FILE, "<$tmpfile" ) || die "Cannot open $tmpfile: $!";

	undef $/; # switch into 'slurp' mode

	my $content = <FILE>;
	my @list = split (/\s/,$content);
	foreach my $word (@list)
	{
	    chomp $word;
	    $word =~ s/\s+//mg;
	    $word =~ s/[,.;:?]+//mg;
	    
	    if($word ne "") {
		push @words, $word;
	    }
	}
	close(FILE);
	
	system("rm $tmpfile");

	return (@words);
}

1;
