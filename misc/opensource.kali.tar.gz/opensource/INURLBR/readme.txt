

 0xGRUPO GOOGLEINURL BRASIL - ADVANCED RESEARCH.
 0xSCRIPT NAME: INURLBR
 0xAUTOR:    Cleiton Pinheiro
 0xNick:     Googleinurl
 0xBlog:     http://blog.inurl.com.br
 0xtwitter:  /@googleinurl
 0xfacebook: /InurlBrasil
 0xVersão:    1.0.1




                           [ INURLBR + NETOOL TOOLKIT INTERACTION ]
+===========================================================================================+
|                                                                                           |
| GOOGLEINURL WORK PATH    : /usr/bin                                                       |
| GOOGLEINURL T00LKIT PATH : /root/opensource/INURLBR                                       |
| LOGFILES STORAGE         : /root/opensource/logs                                          |
| EXTERNAL SCRIPTS         : http://pastebin.com/u/Googleinurl                              |
|                                                                                           |
| USING EXPLOITS           : --comand-all "php /<PATH-TO>/exploit.php _TARGET_"             |
| EXAMPLE : inurlbr.php --dork 'inurl:/wp-content/themes/echelon' -q 1,2,10 -s save.log     |
|           --comand-all "php /root/opensource/INURLBR/exploit.php _TARGET_"                |
|                                                                                           |
+===========================================================================================+
