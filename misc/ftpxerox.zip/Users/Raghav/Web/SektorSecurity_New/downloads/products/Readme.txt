	===========================================
                     FTPXerox v.1.0
	   Copyright � 1999-2001, Sektor:Security
	===========================================

September 08, 2001

========
CONTENTS
========
� About FTPXerox
� System Requirements
� Installing FTPXerox
� License Agreement
� Contacting Us
� What's New
� Notes
� Bugs
� Other Products by Sektor:Security
� Author

===============
About FTPXerox
===============
FTPXerox grabs files that are transferred across the network 
using the FTP protocol. It was written to demonstrate the fact 
that any "clear-text" file transfer protocol is susceptible to 
such attacks. It implements a full end-to-end TCP re-assembly 
engine that watches for FTP transfers. Once the engine detects 
an FTP file transfer, it grabs the file off the wire and stores 
it in a local file. It is quite intelligent in the sense, it can 
reconstruct exact file names and even grab binary files! Version 
1.0, however, does NOT support PASV mode file transfers.

It is still in Beta. So, report any bugs/comments to me. 

===================
System Requirements
===================
� An Ethernet network card supporting the NDIS 3.0 driver standard
� Pentium 60 or faster. 
� Windows NT (Sevice Pack 3 or above). 
� WinPcap Drivers v 2.02 

====================
Installing FTPXerox
====================
� Unzip the ZIP archive to a temporary folder.
� Verify the MD5 Checksum.
� Execute FTPXerox.exe

=================
License Agreement
=================
Free for non-commerical use. If you use it for commercial
purposes, please give credit to Sektor:Security. Mention
the website (http://members.fortunecity.com/sektorsecurity)
and the author (FoxThree (foxthree@antionline.org)).

Disclaimer
THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT
LIMITED TO WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
A PARTICULAR PURPOSE.  IN NO EVENT WILL SEKTOR:SECURITY
BE LIABLE TO YOU FOR ANY DAMAGES, INCLUDING INCIDENTAL
OR CONSEQUENTIAL DAMAGES, ARISING OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGES. YOU ACKNOWLEDGE THAT YOU HAVE READ THIS
LICENSE, UNDERSTAND IT AND AGREE TO BE BOUND BY ITS
TERMS.

Distribution
This software may be distributed freely in its original
unmodified and unregistered form. The distribution has
to include all files of its original distribution.
Distributors may not charge any money for it. Anyone
distributing this software for any kind of remuneration
must first contact us for authorization.

Other Restrictions
You may not modify, reverse engineer, decompile or
disassemble this software in any way, including
changing or removing any messages or windows.

=============
Contacting Us
=============
Questions? Comments? Suggestions? Bug reports? Don't 
hesitate to contact us. 

WWW:	http://members.fortunecity.com/sektorsecurity
	http://sektorsecurity.gq.nu
	http://sektorsecurity.4u.ru
E-mail:	foxthree@antionline.org
        sektorsecurity@theunknown.com

==========
What's New
==========

Version 1.0

� Public release

=====
Notes
=====

� Due to the way the TCP re-assembly engine is implemented,
  FTPXerox can also give directory listing commands (NLST),
  (LIST) etc in a file. These files will be of the form
  "fnXXXXXX". This is just extra information. We plan to 
  fix that in the next release. If you do not need 
  directory listings, just delete these files as and when
  they're formed.

====
Bugs
====

� None so far.

=================================
Other Products by Sektor:Security
=================================

ShareMon - ShareMon for Windows NT is a "real-time" 
Windows NT share watcher. When run on a system, it 
watches the systems shares and logs connections to the 
shares. It can be used to obtain share usage patterns 
and who connected to the share for how long. It sits 
conveniently in the system tray. It also generates logs 
that can be backed up by the system administrator. 

You can learn more about these products at
http://members.fortunecity.com/sektorsecurity/projects.html

=======
Author
=======
FoxThree 
(foxthree@antionline.org)